function zstats_chosen_value

dir_fig = 'figures';
nSubj=28;
model='GLM_1';
cope=7;
region='mPFC';


    wl_beta = NaN(nSubj,3);
    
    
    regFile = sprintf('fMRI_GLM/%s/beta_dir_leave_one_out/%s/%s_cope%d.txt',model,region,region,cope);
    cope_beta=load(regFile);
    wl_beta(:,1)=cope_beta;
    val_mean = mean(cope_beta);
    val_sem = std(cope_beta)./sqrt(size(cope_beta,1));
    
    beta_mean = val_mean;
    beta_sem = val_sem;




    figure
    hold on
    fg = fig_setting_default();
    nrow = size(beta_mean,1);
    ncol = size(beta_mean,2);
    h = bar(beta_mean);
    drawnow;
    for j = 1:ncol
%         xposition = get(get(h(j),'children'),'xdata');
%         barsx(1:nrow, j) = mean(xposition,1);
        barsx(1:nrow,j) = h.XData + h.XOffset;
    end
    errorbar(barsx, beta_mean,beta_sem, 'Marker','none','LineStyle','none');
    set(gca, 'XTick', mean(barsx,2), 'XTickLabel', region);
    
    % output figure
    print(fullfile(dir_fig,['z_stats_chosen_value_model_',model]), '-dpng');



