function [low_var, high_var]=beta_var_and_range


%This function is used to stimulate the theoratical correlation between 
%variance/std and the distance between 90% interval range, and is used to
%calculate the relationship between the 90% interval range subjects' 
%estimated with standard value

% directories
dir_fig = 'figures';

var_fcn = @(a,b)(a*b)/((a+b+1)*(a+b)^2);

%load the prior data
[prediction_allData,allData_confidence_interval,final_allData_confidence_interval]=group_prior_information;
nSubj=28;

% confidence range
confidence_range = final_allData_confidence_interval(:,2,:)-final_allData_confidence_interval(:,1,:);
confidence_range = confidence_range/100;
range_mean = mean(confidence_range,3);
range_sd = std(confidence_range,0,3);
range_sem = range_sd./sqrt(nSubj);

n=12;
low_var = var_fcn(n,n);
low_var_sd=sqrt(low_var);

low_var_range=range_mean(1);
seData_low=range_sem(1);

n=2;
high_var = var_fcn(n,n);
high_var_sd=sqrt(high_var);

high_var_range=range_mean(2);
seData_high=range_sem(2);

% standard deviation of probability estimates
finalBlock = [121:150];
final_prediction_allData = prediction_allData(:,finalBlock,:);
final_prediction_allData = final_prediction_allData/100;
prediction_sd = std(final_prediction_allData,0,2);
prediction_sd_mean = mean(prediction_sd,3);
prediction_sd_sem = std(prediction_sd,0,3)./sqrt(nSubj);

low_var_prediction_sd_mean = prediction_sd_mean(1);
low_var_prediction_sd_sem = prediction_sd_sem(1);

high_var_prediction_sd_mean = prediction_sd_mean(2);
high_var_prediction_sd_sem = prediction_sd_sem(2);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% theoratical value %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% simulation
list_n = [1:100];
idx_var = zeros(numel(list_n),2);
idx_sd = zeros(numel(list_n),2);


for i = 1:numel(list_n)
    %   y_name=sprintf('%d_range_%d_beta',90,2*n);
    
    n = list_n(i);
    
    y_name = icdf('beta',[0.05,0.95],n,n);
    d_range = y_name(2)-y_name(1);
    
    x_name = var_fcn(n,n);
    x_name_sd = sqrt(x_name);
    
    idx_var(i,1) = x_name;
    idx_var(i,2) = d_range;
    
    idx_sd(i,1) = x_name_sd;
    idx_sd(i,2) = d_range;
    
end


%%fitting variance
% y = c*x.^a
% logy = logc*x.^a = alogx+logc
% y' = ax'+c'
% c = exp(c')
b_var=glmfit(log(idx_var(:,1)),log(idx_var(:,2)),'normal');

%%fitting standard deviation
% y = c*x
b_sd=glmfit(idx_sd(:,1),idx_sd(:,2),'normal','constant','off');



%%%%%%%%%%%%%%%%%%%%%%
%%%%% figures %%%%%
%%%%%%%%%%%%%%%%%%%%%%

figure
fg = fig_setting_default();
hold on

plot(0,0,'d');
plot(idx_var(:,1),idx_var(:,2),'d','MarkerSize',12);
plot(idx_var(:,1),exp(b_var(1))*idx_var(:,1).^b_var(2),'MarkerSize',12);
plot(low_var,low_var_range,'ro','MarkerFaceColor','r','MarkerSize',12);
plot(high_var,high_var_range,'ro','MarkerFaceColor','r','MarkerSize',12);

xlabel('prior variability(var)');
ylabel('90% interval estimate');
hold off

% output figure
print(fullfile(dir_fig,'prior_beta_var_range'), '-depsc');

figure
fg = fig_setting_default();

hold on

plot(0,0,'d');
plot(idx_sd(:,1),idx_sd(:,2),'d','MarkerSize',12);
plot(idx_sd(:,1),(idx_sd(:,1)).*b_sd,'MarkerSize',12);
plot(low_var_sd,low_var_range,'ro','MarkerFaceColor','r','MarkerSize',12);
e = errorbar(low_var_sd, low_var_range,seData_low);
                set(e,...
                'Marker','none',...
                'LineStyle','none',...
                'linewidth', 1,...
                'Color', 'k'...
                );
plot(high_var_sd,high_var_range,'ro','MarkerFaceColor','r','MarkerSize',12);
e = errorbar(high_var_sd, high_var_range,seData_high);
                set(e,...
                'Marker','none',...
                'LineStyle','none',...
                'linewidth', 1,...
                'Color', 'k'...
                );
xlabel('prior variability(std)');
ylabel('90% interval estimate');
hold off

% output figure
print(fullfile(dir_fig,'prior_beta_std_range'), '-depsc');




