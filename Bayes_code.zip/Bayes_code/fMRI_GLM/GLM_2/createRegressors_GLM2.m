function createRegressors_GLM2(subID)

%This function shows how to create regressors in GLM2 form sorted data(fMRI_onset)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% Regressors %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%R01_small_variance_3_dots_prior_likelihood_onset  %
%%R02_small_variance_3_dots_likelihood_mean         %
%%R03_small_variance_15_dots_prior_likelihood_onset %
%%R04_small_variance_15_dots_likelihood_mean        %
%%R05_large_variance_3_dots_prior_likelihood_onset  %
%R06_large_variance_3_dots_likelihood_mean          %
%%R07_large_variance_15_dots_prior_likelihood_onset %
%%R08_large_variance_15_dots_likelihood_mean        %
%%R09_choice_onset                                  %
%%R10_alternative_lottery                           %
%%R11_posterior_mean                                %
%%R12_posterior_sd                                  %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% directories
dirOnset = fullfile('..', '..', 'fMRI_onset');
dirRegressor = fullfile(subID);
mkdir(dirRegressor);%make Regressor director

%load files and data
onsetFile = fullfile(dirOnset, sprintf('%s_fmri_onset_1120.mat', subID));
load(onsetFile);
onsetTitle = fmri_onset.onsetTitle;
data = fmri_onset.allOnset;

%condition
nameVariance = {'small_variance', 'large_variance'}; % 1, 2
nameDots = [3,  15]; % dots
nVariance = numel(nameVariance);
nDots = numel(nameDots);

%find information
idx_block = find(strcmp(onsetTitle, 'block'));
idx_choice = find(strcmp(onsetTitle, 'choice'));
idx_prior_variance=find(strcmp(onsetTitle,'prior_var_index'));
idx_dots = find(strcmp(onsetTitle, 'likelihood_dots'));
nBlock = max(data(:,idx_block));

for b = 1:nBlock
    
    % count regressors
    n_regressor = 0;
    
    % check block and choice
    
    idx = (data(:,idx_block)==b)&(data(:,idx_choice)~=-1); %remove trials that subjects did not response
    
    %%find the regressor in each condition
    for v = 1:nVariance
        for d = 1:nDots
            
            idx_cond = (data(:, idx_prior_variance)==v)& (data(:, idx_dots)==nameDots(d));
            idx_include = idx&idx_cond;
            
            % prior_likelihood_onset
            n_regressor = n_regressor+1;
            type = sprintf('R%.2d_%s_%d_dots_prior_likelihood_onset',n_regressor,nameVariance{v},nameDots(d));
            col = [...
                find(strcmp(onsetTitle, 'prior_likelihood_onset')),... % onset
                find(strcmp(onsetTitle, 'prior_likelihood_duration'))... % duration
                ];
            regressorFile = fullfile(dirRegressor, sprintf('%s_F%.1d_%s.txt', subID, b, type));
            regressorData = [data(idx_include, col), ones(sum(idx_include), 1)];
            dlmwrite(regressorFile, regressorData, 'delimiter', '\t');
            
            
            %likelihood_of_reward (likelihood_mean)
            n_regressor = n_regressor+1;
            type = sprintf('R%.2d_%s_%d_dots_likelihood_mean',n_regressor,nameVariance{v},nameDots(d));
            col = [...
                find(strcmp(onsetTitle, 'prior_likelihood_onset')),... % onset
                find(strcmp(onsetTitle, 'prior_likelihood_duration')),... % duration
                find(strcmp(onsetTitle, 'likelihood_mean'))... % likelihood_mean
                ];
            regressorFile = fullfile(dirRegressor, sprintf('%s_F%.1d_%s.txt', subID, b, type));
            regressorData = data(idx_include, col);
            dlmwrite(regressorFile, regressorData, 'delimiter', '\t');
        end
    end
    
    %%Across all trials
    % choice_onset
    n_regressor = n_regressor+1;
    type = sprintf('R%.2d_choice_onset',n_regressor);
    col = [...
        find(strcmp(onsetTitle, 'choice_onset')),... % onset
        find(strcmp(onsetTitle, 'RT'))... % duration
        ];
    regressorFile = fullfile(dirRegressor, sprintf('%s_F%.1d_%s.txt', subID, b, type));
    regressorData = [data(idx, col), ones(sum(idx), 1)];
    dlmwrite(regressorFile, regressorData, 'delimiter', '\t');
    
    %alternative_lottery
    n_regressor = n_regressor+1;
    type = sprintf('R%.2d_alternative_lottery',n_regressor);
    col = [...
        find(strcmp(onsetTitle, 'choice_onset')),... % onset
        find(strcmp(onsetTitle, 'RT'))... % duration
        find(strcmp(onsetTitle, 'alternative_lottery'))...% alternative_lottery
        ];
    regressorFile = fullfile(dirRegressor, sprintf('%s_F%.1d_%s.txt', subID, b, type));
    regressorData = data(idx, col);
    dlmwrite(regressorFile, regressorData, 'delimiter', '\t');
    
    %posterior prob reward of symbol(posterior_mean)
    n_regressor = n_regressor+1;
    type = sprintf('R%.2d_posterior_mean',n_regressor);
    col = [...
        find(strcmp(onsetTitle, 'choice_onset')),... % onset
        find(strcmp(onsetTitle, 'RT'))... % duration
        find(strcmp(onsetTitle, 'posterior_mean'))...% alternative_lottery
        ];
    regressorFile = fullfile(dirRegressor, sprintf('%s_F%.1d_%s.txt', subID, b, type));
    regressorData = data(idx, col);
    dlmwrite(regressorFile, regressorData, 'delimiter', '\t');
    
    
    
    %posterior sd symbol
    n_regressor = n_regressor+1;
    type = sprintf('R%.2d_posterior_sd',n_regressor);
    col = [...
        find(strcmp(onsetTitle, 'choice_onset')),... % onset
        find(strcmp(onsetTitle, 'RT'))... % duration
        ];
    posterior_var_idx =find(strcmp(onsetTitle, 'posterior_var'));
    posterior_sd = sqrt(data(idx, posterior_var_idx));
    
    
    regressorFile = fullfile(dirRegressor, sprintf('%s_F%.1d_%s.txt', subID, b, type));
    regressorData = [data(idx, col), posterior_sd];
    dlmwrite(regressorFile, regressorData, 'delimiter', '\t');
end

