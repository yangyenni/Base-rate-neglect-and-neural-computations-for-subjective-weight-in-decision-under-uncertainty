function group_ROI_PPI1()

% directory
model_name = 'PPI_1';
dir_fig = 'figures';
mkdir(dir_fig);

%%%%% beta_dir_LOSO/beta_dir %%%%%
dirBeta = fullfile('fMRI_GLM',model_name, 'beta_dir_leave_one_out');
dirModel_HarvardOxford = fullfile('fMRI_GLM',model_name, 'beta_dir');

% list_ROI
list_ROI = {
    'mPFC';
    'OFC_ROI_peak_mask25';
%     'LPutamen';
%     'RPutamen';
    };
nROI = numel(list_ROI);

data = [];
for r = 1:nROI
    
    % roi_name
    roi_name = list_ROI{r};
    
    % load data
    switch roi_name
        case {'mPFC'}
            filename = sprintf('%s_cope34.txt', roi_name);
            filename = fullfile(dirBeta, roi_name, filename);
        case {'LPutamen','RPutamen'}
            filename = sprintf('HarvardOxford_%s_cope34.txt', roi_name);
            filename = fullfile(dirModel_HarvardOxford, sprintf('HarvardOxford_%s', roi_name), filename);
        case {'OFC_ROI_peak_mask25'}
            filename = fullfile(dirBeta,roi_name,sprintf('%s_cope34.txt', roi_name));
    end
    data(:,r) = load(filename);
    
end

% figure
nSub = size(data,1);

meanData = mean(data,1);
semData = std(data,0,1)./sqrt(nSub);

figure;
fig_setting_default;

hold on


h_bar = bar(meanData,...
    'linewidth', 2,...
    'barwidth', 0.6,...
    'facecolor', 'w',...
    'edgecolor', 'k');

h_error = errorbar([1:nROI], meanData, semData,...
    'color', 'k',...
    'linestyle', 'none',...
    'linewidth', 2);

hold off

set(gca, 'XTick', [1:nROI], 'XTicklabel', list_ROI);

set(gca, 'fontsize', 24, 'linewidth', 2);

xlabel('ROI', 'fontsize', 24);
ylabel('COPE', 'fontsize', 24);

xlim([0.5, nROI+0.5]);
yrange = ylim;
yrange = yrange + [(yrange(2)-yrange(1)), (yrange(2)-yrange(1))].*[-1, 1]*0.15;
ylim(yrange);

% pval
[h, pval,CI,stats] = ttest(data);
for c = 1:nROI
    
    idx_p = 0;
    if pval(c)<0.001
        idx_p = 1;
        text_p = '***';
    elseif pval(c)>=0.001 & pval(c)<0.01
        idx_p = 1;
        text_p = '**';
    elseif pval(c)>=0.01 & pval(c)<0.05
        idx_p = 1;
        text_p = '*';
    end
    
    if idx_p==1
        x = c;
        if meanData(c)>=0
            y = meanData(c) + semData(c) + (yrange(2)-yrange(1))*0.06;
        else
            y = meanData(c) - semData(c) - (yrange(2)-yrange(1))*0.06;
        end
        text(x, y, text_p,...
            'HorizontalAlignment', 'center',...
            'fontsize', 30);
    end
end

% output figure
outputfile = fullfile(dir_fig, sprintf('LOSO_roi_%s_orig', model_name));
print(outputfile,'-depsc');
savefig([outputfile, '.fig']);


