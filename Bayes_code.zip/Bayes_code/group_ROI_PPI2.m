function group_ROI_PPI2()

% directory
model_name = 'PPI_2';
dir_fig = 'figures';
mkdir(dir_fig);

%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% beta_dir_LOSO%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%
dirBeta_HarvardOxford = fullfile('fMRI_GLM', model_name, 'beta_dir');
dirBeta = fullfile('fMRI_GLM',model_name, 'beta_dir_leave_one_out');


% list_ROI
list_ROI = {
    'OFC_ROI_peak_mask25';
    'mPFC';
%     'LPutamen';
%     'RPutamen';  
    };
nROI = numel(list_ROI);


%%%%% bargraph %%%%%
% list_cope
list_cope = {
    7, 'Prior';
    8, 'Likelihood';
    };
nCope = size(list_cope,1);


%clear allData;
for r = 1:nROI    
    % roi_name
    roi_name = list_ROI{r};
    
    allData.(roi_name) = [];
    for c = 1:nCope
        
        % cope_num
        cope_num = list_cope{c,1};
        
        % load data
        switch roi_name
            case {'OFC_ROI_peak_mask25','mPFC'}

                filename = sprintf('%s_cope%d.txt', roi_name, cope_num);
                filename = fullfile(dirBeta, roi_name, filename);
            case {'LPutamen','RPutamen'}
                filename = sprintf('HarvardOxford_%s_cope%d.txt', roi_name, cope_num);
                filename = fullfile(dirBeta_HarvardOxford, sprintf('HarvardOxford_%s', roi_name), filename);
 
        end
        allData.(roi_name)(:,c) = load(filename);
        
    end 
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% plot figure for each ROI %%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
for r = 1:nROI
    
    % roi_name
    roi_name = list_ROI{r};
    
    data = allData.(roi_name);
    
    nSub = size(data,1);
    
    meanData = mean(data,1);
    semData = std(data,0,1)./sqrt(nSub);
    
    figure;
    fig_setting_default;
    
    hold on
    
    
    h_bar = bar(meanData,...
        'linewidth', 2,...
        'barwidth', 0.4,...
        'facecolor', 'w',...
        'edgecolor', 'k');
    
    h_error = errorbar([1:nCope], meanData, semData,...
        'color', 'k',...
        'linestyle', 'none',...
        'linewidth', 2);
    
    hold off
    
    set(gca, 'XTick', [1:nCope], 'XTicklabel', list_cope(:,2));
    xlabel('Factor', 'fontsize', 24);
    ylabel('COPE', 'fontsize', 24);
    
    title(roi_name, 'fontsize', 24);
    
    set(gca, 'fontsize', 24, 'linewidth', 2);
    
    xlim([0.5, nCope+0.5]);
    yrange = ylim;
    yrange = yrange + [(yrange(2)-yrange(1)), (yrange(2)-yrange(1))].*[-1, 1]*0.15;
    ylim(yrange);
    
    % pval
    [h, pval] = ttest(data);
    for c = 1:nCope
        
        idx_p = 0;
        if pval(c)<0.001
            idx_p = 1;
            text_p = '***';
        elseif pval(c)>=0.001 & pval(c)<0.01
            idx_p = 1;
            text_p = '**';
        elseif pval(c)>=0.01 & pval(c)<0.05
            idx_p = 1;
            text_p = '*';
        end
        
        if idx_p==1
            x = c;
            if meanData(c)>=0
                y = meanData(c) + semData(c) + (yrange(2)-yrange(1))*0.06;
            else
                y = meanData(c) - semData(c) - (yrange(2)-yrange(1))*0.06;
            end
            text(x, y, text_p,...
                'HorizontalAlignment', 'center',...
                'fontsize', 30);
        end
    end
    
    for c = 1:nCope
        
        if pval(c)<0.001
            text_p = sprintf('p=%.2e', pval(c));
        else
            text_p = sprintf('p=%.3f', pval(c));
        end
        
        x = c;
        if meanData(c)>=0
            y = meanData(c) + semData(c) + (yrange(2)-yrange(1))*0.06;
        else
            y = meanData(c) - semData(c) - (yrange(2)-yrange(1))*0.06;
        end
        text(x, y, text_p,...
            'HorizontalAlignment', 'center',...
            'fontsize', 20);
        
    end
    
    data_diff = data(:,1) - data(:,2);
    [h, pval] = ttest(data_diff);
    if pval<0.001
        text_p = sprintf('p=%.2e', pval);
    else
        text_p = sprintf('p=%.3f', pval);
    end
    x = 1.5;
    y = yrange(2) - (yrange(2)-yrange(1))*0.05;
    text(x, y, text_p,...
        'HorizontalAlignment', 'center',...
        'fontsize', 20);
    
    % output figure
    outputfile = fullfile(dir_fig, sprintf('LOSO_%s_roi_%s_Orig', roi_name, model_name));
    print(outputfile,'-depsc');
    savefig([outputfile, '.fig']);
    
end








%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% combine ROIs %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%
% data =[allData.LPutamen,allData.RPutamen];
data = [allData.mPFC, allData.OFC_ROI_peak_mask25];
nSub = size(data,1);
nData = size(data,2);

xData = [0.7,1.3, 2.1,2.7];

meanData = mean(data,1);
semData = std(data,0,1)./sqrt(nSub);

figure;
fg = fig_setting_default;
fg.pp(3) = fg.pp(3)*1.5;
set(gcf,...
    'Position',fg.pp,...
    'PaperPosition', fg.pp);

hold on


h_bar = bar(xData, meanData,...
    'linewidth', 2,...
    'barwidth', 0.85,...
    'facecolor', 'w',...
    'edgecolor', 'k');

h_error = errorbar(xData, meanData, semData,...
    'color', 'k',...
    'linestyle', 'none',...
    'linewidth', 2);

hold off

xticklabel = repmat(list_cope(:,2), 1, nData/2);
set(gca, 'XTick', xData, 'XTicklabel', xticklabel);
set(gca, 'fontsize', 18, 'linewidth', 2);
ylabel('COPE', 'fontsize', 24);

xlim([min(xData)-0.5, max(xData)+0.5]);
yrange = ylim;
yrange = yrange + [(yrange(2)-yrange(1)), (yrange(2)-yrange(1))].*[-1, 1]*0.15;
ylim(yrange);

% pval
[h, pval,CI,stats] = ttest(data)
for c = 1:nData
    
    idx_p = 0;
    if pval(c)<0.001
        idx_p = 1;
        text_p = '***';
    elseif pval(c)>=0.001 & pval(c)<0.01
        idx_p = 1;
        text_p = '**';
    elseif pval(c)>=0.01 & pval(c)<0.05
        idx_p = 1;
        text_p = '*';
    end
    
    if idx_p==1
        x = xData(c);
        if meanData(c)>=0
            y = meanData(c) + semData(c) + (yrange(2)-yrange(1))*0.06;
        else
            y = meanData(c) - semData(c) - (yrange(2)-yrange(1))*0.06;
        end
        text(x, y, text_p,...
            'HorizontalAlignment', 'center',...
            'fontsize', 30);
    end
end


% output figure
%outputfile = fullfile(dir_fig, sprintf('roi_putamen_%s_wl', roi_name, model_name));
outputfile = fullfile(dir_fig, sprintf('LOSO_roi_mPFC_OFC_%s_wl', roi_name, model_name));
print(outputfile,'-depsc');
savefig([outputfile, '.fig']);



