function group_ROI_GLM3()

% directory
model_name = 'GLM_3';
dir_fig = 'figures';
mkdir(dir_fig);

%calculation delta
[allData, stats] = group_mle_uncertainty_condition([],0);
r=allData{3};

ideal_r=[0.1107,0.4400;
    0.3781,0.7757];

% behav_delta= sum of delta across four conditions - overall mean
delta=r-repmat(ideal_r,[1,1,28]);
delta_sum=sum(sum(delta,1),2);
behav_delta=delta_sum-mean(delta_sum(:));



%%%%%%%%%%%%%%%%%%%%
%%%%% beta_dir %%%%%
%%%%%%%%%%%%%%%%%%%%
dirBeta = fullfile('fMRI_GLM', model_name, 'beta_dir');


% list_ROI
list_ROI = {
    'LPutamen';
    'RPutamen';
    };
nROI = numel(list_ROI);


%%%%% correlation %%%%%
% list_cope
list_cope = {
    13, 'Prior - Likelihood';
    };
nCope = size(list_cope,1);


clear allData;
for r = 1:nROI
    
    % roi_name
    roi_name = list_ROI{r};
    
    allData.(roi_name) = [];
    for c = 1:nCope
        
        % cope_num
        cope_num = list_cope{c,1};
        
        % load data
        filename = sprintf('HarvardOxford_%s_cope%d.txt', roi_name, cope_num);
        filename = fullfile(dirBeta, sprintf('HarvardOxford_%s', roi_name), filename);
        allData.(roi_name)(:,c) = load(filename);
        
    end
    
    
end

% figure
for r = 1:nROI
    
    % roi_name
    roi_name = list_ROI{r};
    
    data = allData.(roi_name);
    
    xData = reshape(behav_delta,28,1);
    yData = data;
    
    [rho, pval] = corr(xData,yData);
    
    [beta] = glmfit(xData, yData);
    xhat = [min(xData), max(xData)]';
    yhat = glmval(beta, xhat, 'identity');
    
    
    
    figure;
    fig_setting_default;
    
    hold on
    
    plot(xhat, yhat,...
        'linestyle', '-',...
        'linewidth', 2,...
        'color', 'k');
    
    plot(xData, yData,...
        'linestyle', 'none',...
        'linewidth', 2,...
        'marker', 'o',...
        'markersize', 10,...
        'markerfacecolor', 'w',...
        'markeredgecolor', 'k');
    
    hold off
    
    xlabel('behavior delta', 'fontsize', 24);
    ylabel('COPE: Prior - Likelihood', 'fontsize', 24);
    
    title(sprintf('%s\nr=%.3f, p=%.3f', roi_name, rho, pval), 'fontsize', 24);
    
    set(gca, 'fontsize', 24, 'linewidth', 2);
    
    % output figure
    outputfile = fullfile(dir_fig, sprintf('HarvardOxford_%s_roi_%s_corr_behav_delta', roi_name, model_name));
    print(outputfile,'-depsc');
    savefig([outputfile, '.fig']);
    
end
