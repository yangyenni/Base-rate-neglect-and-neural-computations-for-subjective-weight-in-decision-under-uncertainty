function [beta]=ROI_figure_mSFC

%This function plot the calculated the beta value extracted from dACC

%condition
name_directory='mSFC';
model = 'GLM_3';
cope = [2,3];
% cope2: prior variability;
% cope3: likelihood variability
nSubj=28;

% directory
dir_fig = 'figures';
dir_reg = sprintf('fMRI_GLM/%s/Leave_one_out_beta/%s',model,name_directory);



%form a metrix for ROI(beta)
beta = zeros(nSubj,length(cope));
idx_cope=0;
for s = 1:size(cope,2)
    idx_cope=idx_cope+1;
    regFile = fullfile(dir_reg, sprintf('%s_cope%d.txt', name_directory,  cope(idx_cope)));
    cope_beta=load(regFile);
    for n=1:nSubj
        beta(n,s) = cope_beta(n);
    end
    
end


%%%%%%%%%%%%%%%%%%%%%%
%%%%% figures %%%%%
%%%%%%%%%%%%%%%%%%%%%%

%plot the beta for prior and likelihood reliability
barData=mean(beta,1);
stdData=std(beta,1);
seData = stdData./sqrt(nSubj);
for n_p=1:size(beta,2)
    [H,P,CI,stats]=ttest(beta(:,n_p));
    pval(n_p)=P;
end
bar_color = {...
    [0.2,0.4,1];
    [1,0.2,0.2]
    };


figure
fg = fig_setting_default();


hold on
nrow = size(barData,1);
ncol = size(barData,2);
h = bar(barData);
set(h, ...
    'EdgeColor', bar_color{1},...
    'FaceColor', bar_color{1}...
    );

barsx = h.XData;

e = errorbar(barsx, barData,seData);
set(e,...
    'Marker','none',...
    'LineStyle','none',...
    'linewidth', 3,...
    'Color', 'k'...
    );


set(gca, 'XTick', barsx, 'XTickLabel', {'Prior', 'Likelihood'});

title(name_directory, 'interpreter', 'none');
hold off
ylim([-250,150]);

yrange = ylim;

for i = 1:numel(pval)
    
    idx_p = 0;
    if pval(i)<.05 & pval(i)>=0.01
        idx_p = 1;
        text_p = '*';
    elseif pval(i)<0.01 & pval(i)>=0.001
        idx_p = 1;
        text_p = '**';
    elseif pval(i)<0.001
        idx_p = 1;
        text_p = '***';
    end
    
    if idx_p==1
        x = i;
        if barData(i)>=0
            y = barData(i)+seData(i) + 0.03*(max(yrange)-min(yrange));
        else
            y = barData(i)-seData(i) - 0.03*(max(yrange)-min(yrange));
        end
        text(x,y,text_p,'HorizontalAlignment','center','fontsize',24);
        
    end
    
end

% output figure
print(fullfile(dir_fig,['prior_likelihood_beta_', name_directory]),'-depsc');



