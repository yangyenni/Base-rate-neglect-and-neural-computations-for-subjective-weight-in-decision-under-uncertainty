function get_subjects_wL
% Make several plots on wL estimated from behavior.
% Figure 1 here should correspond to Figure 3C in the paper (Yang & Wu, 2019 bioRxiv).
% Figure 2 and 3 should correspond to Figure 3DE in the paper.
%
% Shih-Wei Wu.2019.
% neuroecon.ym.edu.tw

dir_fig='figures';

% load probability estimate
[prediction_allData,final_allData_confidence_interval,final_allData_average_reward]=group_prior_information;

%load subjects_estimation_orig
% prediction_allData(prior variance, trial, subject)  row 1: small prior
% variance; row 2: large prior variance

% load 90% confidence interval on probability of reward
%load 90_interval_estimation_orig

%load allData_orig

allData_confidence_interval = final_allData_confidence_interval./100;
% allData_confidence_interval(dots, prior_var, subjects)
% dots = 1 --> 3 dots
% dots = 2 --> 15 dots
% prior_var = 1 --> small
% prior_var = 2 --> large

%load ideal wL
data = load('wL_bayes.mat');
wL_ideal = data.table.wL_bayes;

% Please see attach. wl_data{1}=b; wl_data{2}=c; wl_data{3}=wl;
% and the arrangement is allData{i}(dots, prior_var, subjects); (sequence of dots:3,15; prior_var:small, large)
% If it is not clear please check "group_mle_uncertainty_condition" in the dropbox folder.
allData=group_mle_uncertainty_condition;
wL = allData{3};
n_subj = size(wL,3);
n_L = size(wL,1);
n_pi = size(wL,2);
n_cond = n_L*n_pi;

x = 1:2:7;
wL_new = zeros(n_subj,n_cond);  % make wL a 2D matrix
% col 1: small prior variance, large likelihood variance
% col 2: small prior variance, small likelihood variance
% col 3: large prior variance, large likelihood variance
% col 4: large prior variance, small likelihood variance

CI_raw = wL_new;

figure(1);clf
hold on;
count = 0;
for i=1:n_pi
    for j=1:n_L
        count = count+1;
        c_wL = wL(j,i,:);   %current wL
        c_wL = squeeze(c_wL);
        mu(count) = mean(c_wL);    %mean of current wL
        se(count) = std(c_wL)./sqrt(n_subj);   %standard error of current wL
        
        wL_new(:,count) = c_wL;

        % random location to show wL
        x_grid = x(count)*ones(n_subj,1);
        randL = rand(n_subj,1)-0.5;
        x_grid = x_grid+randL;
        
        plot(x_grid,c_wL,'k.','markersize',20);
        hold on;
        plot([x(count)-1 x(count)+1],[wL_ideal(count) wL_ideal(count)],'k-','linewidth',2);
    end
end
errorbar(x,mu,se);
plot(x,mu,'r.','markersize',65);
axis([0 8 -0.05 1.05])
    outputfile = fullfile(dir_fig,'wl_ideal');
    print(outputfile,'-depsc');
    savefig([outputfile, '.fig']);

% get confidence interval
for i=1:n_pi
    for j=1:n_subj
        CI_raw(j,i) = abs(allData_confidence_interval(i,1,j)-allData_confidence_interval(i,2,j));
    end
end
CI_new = [repmat(CI_raw(:,1),1,2) repmat(CI_raw(:,2),1,2)];


for i=1:n_subj
    c_prob = squeeze(prediction_allData(:,:,i))./100;
    sd_prob(i,:) = std(c_prob');
end

sd_prob_new = [repmat(sd_prob(:,1),1,2) repmat(sd_prob(:,2),1,2)];

% linear regression wL = b0+b1*sd_prob;
figure(2);clf
hold on;
figure(3);clf
hold on;
% cmat = [1 0 1;1 0 0;0 1 1;0 1 0];
cmat={
    [1, 0.5, 0.1];
    [1,0,1];
    'c';
    [0.2,0.2,1];
    };
for i=1:n_cond
    
    %%%%% GLM on standard deviation of probability estimate
    [beta,dev,stats] = glmfit(sd_prob_new(:,i),wL_new(:,i),'normal');
    
    glm_sd(i,1).beta = beta;
    glm_sd(i,1).dev = dev;
    glm_sd(i,1).stats = stats;
    
    delta = max(sd_prob_new(:,i))-min(sd_prob_new(:,i));
    lb(i) = min(sd_prob_new(:,i))-0.1*delta;
    if lb(i)<0
        lb(i)=0;
    end
    ub(i) = max(sd_prob_new(:,i))+0.1*delta;
    
    sd_prob_grid = linspace(lb(i),ub(i),100);
    wL_hat = beta(1) + beta(2)*sd_prob_grid;
    
    figure(2);
    plot(sd_prob_new(:,i),wL_new(:,i),'o','markersize',12,'MarkerFaceColor',cmat{i,:},'MarkerEdgeColor',[0 0 0]);
    plot(sd_prob_grid,wL_hat,'linewidth',4,'color',cmat{i,:});
    
    [r,p] = corrcoef(sd_prob_new(:,i),wL_new(:,i));
    r_sd(i,1) = r(1,2);
    r_sd_pval(i,1) = p(1,2);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%%% GLM on confidence interval %%%%%%%%%%%%%%%%%%%%%%
    [beta,dev,stats] = glmfit(CI_new(:,i),wL_new(:,i),'normal');
    
    glm_CI(i,1).beta = beta;
    glm_CI(i,1).dev = dev;
    glm_CI(i,1).stats = stats;
    
    delta = max(CI_new(:,i))-min(CI_new(:,i));
    lb_CI(i) = min(CI_new(:,i))-0.1*delta;
    if lb_CI(i)<0
        lb_CI(i)=0;
    end
    ub_CI(i) = max(CI_new(:,i))+0.1*delta;
    
    CI_grid = linspace(lb_CI(i),ub_CI(i),100);
    wL_hat_CI = beta(1) + beta(2)*CI_grid;
    
    figure(3);
    plot(CI_new(:,i),wL_new(:,i),'o','markersize',12,'MarkerFaceColor',cmat{i,:},'MarkerEdgeColor',[0 0 0]);
    plot(CI_grid,wL_hat_CI,'linewidth',4,'color',cmat{i,:});
    
    [r,p] = corrcoef(CI_new(:,i),wL_new(:,i));
    r_CI(i,1) = r(1,2);
    r_CI_pval(i,1) = p(1,2);
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
end
figure(2);
xlabel('standard deviation of probability estimate')
ylabel('wL');
title(['r: ' num2str(r_sd') '     pval: ' num2str(r_sd_pval')])
axis([0 max(ub) -0.05 1.05])
axis square;   
    outputfile = fullfile(dir_fig,'WL_standard deviation of probability estimate');
    print(outputfile,'-depsc');
    savefig([outputfile, '.fig']);

figure(3);
xlabel('subjects estimated 90% CI')
ylabel('wL');
title(['r: ' num2str(r_CI') '     pval: ' num2str(r_CI_pval')])
axis([0 max(ub_CI) -0.05 1.05])
axis square;  
    outputfile = fullfile(dir_fig,'WL_subjects estimated 90% CI');
    print(outputfile,'-depsc');
    savefig([outputfile, '.fig']);


