function [prediction_allData,final_allData_confidence_interval,final_allData_average_reward]=group_prior_information(sublist, fig_on)


%This function is used to group subjects' prior information, including
%subjects' estimation in all the trials, subjects' confidence interval
%estimation in the end of each block and the mean estimation of the prior 
%distribution in the end of each block


% subject list
if nargin<1
    sublist = textread('sublist','%s','delimiter','\n');
else
    if ~iscell(sublist)
        sublist = {sublist};
    end
end
nSubj = numel(sublist);
% whether to draw figures
if nargin<2
    fig_on = 1;
end


% directories
dir_input = 'input';
dir_data = 'data';
dir_fig = 'figures';

%condition
n_prior=2;
prior_list = {[12,12], [2,2]};
prior_name = {'small variability prior', 'large variability prior'};
bound={'low','high'};
n_bound=numel(bound);

% number of blocks
nBlock = 10;
n_repeats_prior = 30;
n_total_trials = nBlock*n_repeats_prior/n_prior;

% create matrixs to put final data
allData_confidence_interval=zeros(n_prior,n_bound,nSubj);
final_allData_confidence_interval=zeros(n_prior,n_bound,nSubj);
final_allData_average_reward=zeros(n_prior,1,nSubj);
prediction_allData = zeros(n_prior, n_total_trials, nSubj);



% load input and data

for s = 1:nSubj
    subID = sublist{s};
    load(fullfile(dir_input, sprintf('prior_%s.mat', subID)));
    data = load(fullfile(dir_data, sprintf('output_prior_%s.txt', subID)));
    
    % index of prior at each block (identify prior)
    nPrior = numel(inputs(1).prior_symNo);
    prior_all = [inputs.prior_current];
    nBlockPrior=nBlock/nPrior;
    
    % determine prior at each block and sort out subjects' prediction in all trials,
    % confidence interval estimation and  average estimation in the end of each block 
    nRepeat = zeros(1, nPrior);
    ConfidenceInterval = zeros(nPrior, 2, nBlockPrior);
    averageEstimation = zeros(nPrior, nBlockPrior);
    prediction = cell(nPrior,1);
    for b = 1:nBlock
        idx_prior = prior_all(b);
        nRepeat(1, idx_prior) = nRepeat(1, idx_prior)+1;
        idx_repeat = nRepeat(1, idx_prior);
        
        %subject's prediction in all trials 
        idx_block = (data(:,1)==b)&(data(:,2)<=n_repeats_prior);
        prediction{idx_prior} = [prediction{idx_prior}, data(idx_block, 3)'];
        
        %subject's confidence interval in the end of each block
        idx_block = (data(:,1)==b)&(data(:,2)==(n_repeats_prior+1));
        ConfidenceInterval(idx_prior, 1, idx_repeat) = data(idx_block,3);
        ConfidenceInterval(idx_prior, 2, idx_repeat) = data(idx_block,4);
        
        %subject's final average estimation in the end of each block
        idx_block = (data(:,1)==b)&(data(:,2)==(n_repeats_prior+2));
        averageEstimation(idx_prior, idx_repeat) = data(idx_block,3);
        
    end
    
    %cofidence interval and mean estimation in last block
    lastConfidenceInterval(:,1)=ConfidenceInterval(:,1,4);
    lastConfidenceInterval(:,2)=ConfidenceInterval(:,2,4);
    meanConfidenceInterval = mean(ConfidenceInterval, 3);
    lastaverageEstimation=averageEstimation(:, 4);
    
    
    for p=1:n_prior
        for b=1:n_bound
            allData_confidence_interval(p,b,s)=meanConfidenceInterval(p,b);
            final_allData_confidence_interval(p,b,s)=lastConfidenceInterval(p,b);
        end
        final_allData_average_reward(p,1,s)=lastaverageEstimation(p,1);        
        prediction_allData(p, :, s) = prediction{p};
        
    end
end


%%%%%%%%%%%%%%%%%%%%%%
%%%%% figures %%%%%
%%%%%%%%%%%%%%%%%%%%%%


if fig_on
    
    % distribution of prediction
    bin_width = 0.02;
    xCenter = [0:bin_width:1];
    p_grid = [0:0.01:1];
    legend_text = {'Actual probability estimates', 'Theoretical prior distribution', 'estimated 90% interval'};
    for i = 1:nPrior
        
        confidence_interval_low = allData_confidence_interval(i,1,:);
        confidence_interval_high = allData_confidence_interval(i,2,:);    
        confidence_interval_low = confidence_interval_low(:)/100;
        confidence_interval_high = confidence_interval_high(:)/100;
        lowBound = mean(confidence_interval_low);
        highBound = mean(confidence_interval_high);
        lowBound_sem = std(confidence_interval_low)/sqrt(nSubj);
        highBound_sem = std(confidence_interval_high)/sqrt(nSubj);
        
        figure;
        hold on
        fg = fig_setting_default();
        
        % prediction estimates
        x = prediction_allData(i,:,:);
        x = x(:)/100;
        [bin_h, bin_center] = hist(x, xCenter);
        bin_h = bin_h/sum(bin_h);
        h(1) = bar(bin_center, bin_h,...
            'barwidth', 1,...
            'FaceColor', [0.4, 0.4, 0.4],...
            'EdgeColor', [0.4, 0.4, 0.4]...
            );
        
        
        % theoretical prior distribution
        pdf_prior = pdf('beta', p_grid, prior_list{i}(1), prior_list{i}(2));
        pdf_prior = pdf_prior/sum(pdf_prior);
        h(2) = plot(p_grid, pdf_prior,...
            'Color', [0.2,0.4,1],...
            'linewidth', 3 ...
            );
        
        % confidence
        height = 0.0075;
        rect_handle = rectangle('Position', [lowBound, 0, highBound-lowBound, height],...
            'EdgeColor', [1,0.2,0.2],...
            'FaceColor', [1,0.2,0.2]...
            );
        h(3)=plot(nan,nan,'-',...
            'color',get(rect_handle,'facecolor'),...
            'linewidth', 3 ...
            );
        plot([lowBound-lowBound_sem;lowBound+lowBound_sem], [height/2;height/2],...
            'linestyle', '-',...
            'linewidth', 1.5,...
            'color', 'k'...
            );
        plot([highBound-highBound_sem;highBound+highBound_sem], [height/2;height/2],...
            'linestyle', '-',...
            'linewidth', 1.5,...
            'color', 'k'...
            );
        plot([lowBound+lowBound_sem;lowBound+lowBound_sem], [height*0.25;height*0.75],...
            'linestyle', '-',...
            'linewidth', 1.5,...
            'color', 'k'...
            );
        plot([lowBound-lowBound_sem;lowBound-lowBound_sem], [height*0.25;height*0.75],...
            'linestyle', '-',...
            'linewidth', 1.5,...
            'color', 'k'...
            );
        plot([highBound+highBound_sem;highBound+highBound_sem], [height*0.25;height*0.75],...
            'linestyle', '-',...
            'linewidth', 1.5,...
            'color', 'k'...
            );
        plot([highBound-highBound_sem;highBound-highBound_sem], [height*0.25;height*0.75],...
            'linestyle', '-',...
            'linewidth', 1.5,...
            'color', 'k'...
            );
        
        
        
        
        hold off
        xlim([0,1]);
        ylim([0,0.3]);
        ylabel('probability of occurance');
        if i==2
            legend(h,legend_text);
        end
        title(prior_name{i});
        
        % output figure
        print(fullfile(dir_fig, sprintf('prior_learning_%s',prior_name{i})), '-depsc');
        
    end
    
    
    
    %plot average mean of final estimation
    
     final_mean_of_mean_estimate=mean(final_allData_average_reward,3);
     std_mean_estimateion = std(final_allData_average_reward,0,3);
    
    %final_mean_of_mean_estimate=mean(allData_average_reward,3);
    %std_mean_estimateion = std(allData_average_reward,0,3);
    seData = std_mean_estimateion./sqrt(nSubj);
    
    figure
    fg = fig_setting_default();
    for n=1:nPrior
        hold on
        X=[n];
        Y=[50];
        plot(X,Y,'d','MarkerSize',12);
    X= [n];
    Y= final_mean_of_mean_estimate(n);
    plot(X,Y,'ro','MarkerFaceColor','r','MarkerSize',12);
    e = errorbar(X, Y,seData(n));
                set(e,...
                'Marker','none',...
                'LineStyle','none',...
                'linewidth', 1,...
                'Color', 'k'...
                );

    
    xlim([0,3]);
    ylim([40,60]);
    hold off
    end
end
set(gca, 'yTick', [40:5:60]);
set(gca, 'xTick', [1:nPrior], 'xTickLabel', prior_name, 'fontsize', 18);
ylabel('mean estimate');
title('last_average_reward_probability','interpreter','none');
    
print(fullfile(dir_fig,'prior_mean_estimate'), '-depsc');
    





%%%%%%%%%%%%%%%%%%%%%%
%%%%% statistics %%%%%
%%%%%%%%%%%%%%%%%%%%%%
% low var
x = final_allData_average_reward(1,1,:);
x = x(:)-50;
[h,p,ci,stats] = ttest(x);

% high var
x = final_allData_average_reward(2,1,:);
x = x(:)-50;
[h,p,ci,stats] = ttest(x);


