function createInputs_bayes_prior_uncertainty_practice2(subID)
%
% 9/25/2012. Modified from createInputs_bayes_singleLot_fmri.
% The subjects have to choose between the symbol lottery and an alternative
% lottery that differs only in its probability of reward.
%
%
% SWU.2012.
% CCT.2014. http://voteview.com/Beta-Binomial.pdf
% CHK.20141225.

% set random seed depending on current time
rs=sum(100*clock);
rand('state',rs);

% 2 (number of prior distributions) x 3 (likelihood: amount of evidence) design
% In each trial, subjects see a particular combination of prior and
% likelihood. Prior will be represented by a cue. Likelihood will be
% represented by colored dots (yellow and white).  The number of yellow and
% white dots are determined by a probability drawn from the prior distribution.

% name of inputfile
device_type = 'practice2';
inputfile = ['Bayes_prior_uncertainty_' device_type '_' subID '.mat'];
if exist(inputfile,'file')
    error('input file with this subject ID already exists')
end

% Parameters of beta distribution for prior distribution
beta_params = {
    [12,12];
    [2,2]
    };

n_mu = size(beta_params,2);
n_variance = size(beta_params, 1);
n_prior = n_variance*n_mu;

% dots
n_dots = [3 15];
n_evidence = length(n_dots);

% outcome type
outcome = 20;
% gain = [10;20;40;80];
% loss = -1*gain;
% n_outcome = numel(outcome);
% n_outcome = numel(gain);
% n_valence = 2; % gain and loss

% pair each prior with evid. conditions
nBlocks = 1;
n_trials = 8;
n_combination = n_prior*n_evidence;
% all_combination = n_prior*n_evidence*n_valence*n_outcome;

% % Sets up timing jitters.
% btwCueJit = 1:5; % isi between cue and stimuli
% mu_btwCueJit = mean(btwCueJit);
% sum_btwCueJit = mu_btwCueJit*n_trials;

% btwLotJit = 1:5; % isi between stimuli and choice
btwLotJit = 1; % isi between stimuli and choice
mu_btwLotJit = mean(btwLotJit);
sum_btwLotJit = mu_btwLotJit*n_trials;
% itiJit = 1:10; %ITI
itiJit = 2; %ITI
mu_itiJit = mean(itiJit);
sum_itiJit = mu_itiJit*n_trials;

% determine symbols for prior
prior_symNo = load(sprintf('prior_symNo_%s.txt',subID));

% Set up all variables for each block
for i=1:nBlocks
    
    inputs(i,1).nTrialsPB = n_trials; % trials per block
    inputs(i,1).prior_symNo = prior_symNo; % symbols for prior
    
    inputs(i,1).position_option = mod(randperm(n_trials), 2)'+1; % randomly assign positions of option
    inputs(i,1).position_prior = mod(randperm(n_trials), 2)'+1; % randomly assign positions of prior and likelihoood
    
    % Make sure total block length is the same across blocks
    % check ISI
    %     while 1
    %         rand_btwCueJit = round(unifrnd(min(btwCueJit),max(btwCueJit),n_trials,1));
    %         if sum(rand_btwCueJit)==sum_btwCueJit
    %             break
    %         end
    %     end
    % check ISI
    while 1
        rand_btwLotJit = round(unifrnd(min(btwLotJit),max(btwLotJit),n_trials,1));
        if sum(rand_btwLotJit)==sum_btwLotJit
            break
        end
    end
    % check ITI
    while 1
        rand_itiJit = round(unifrnd(min(itiJit),max(itiJit),n_trials,1));
        if sum(rand_itiJit)==sum_itiJit
            break
        end
    end
    
    % combine jitters
    inputs(i,1).t_jitter = [rand_btwLotJit rand_itiJit]; % record jitter in inputs
    
    % Set up all variables for each trial
    inputs(i,1).n_dots = zeros(n_trials, 1);
    inputs(i,1).beta_params = zeros(n_trials, 2);
    inputs(i,1).pRew = zeros(n_trials, 1);
    inputs(i,1).n_red = zeros(n_trials, 1);
    inputs(i,1).posterior = zeros(n_trials, 1);
    inputs(i,1).pRew_alt = zeros(n_trials, 1);
    inputs(i,1).outcome_sym = zeros(n_trials, 1);
    inputs(i,1).outcome_alt = zeros(n_trials, 1);
    
    % all combination of prior X evidence X valence
    designMatrix.prior_mu = zeros(n_trials,1);
    designMatrix.prior_var = zeros(n_trials,1);
    designMatrix.evidence = zeros(n_trials,1);
    idx = 0;
    for v = 1:n_variance
        for m = 1:n_mu
            for e = 1:n_evidence
                for r = 1:n_trials/n_combination  %repeat times
                    idx = idx+1;
                    designMatrix.prior_var(idx) = v;
                    designMatrix.prior_mu(idx) = m;
                    designMatrix.evidence(idx) = e;
                end
            end
        end
    end
    random_design = randperm(n_trials);
    designMatrix.prior_mu = designMatrix.prior_mu(random_design);
    designMatrix.prior_var = designMatrix.prior_var(random_design);
    designMatrix.evidence = designMatrix.evidence(random_design);
    
    
    
    for j=1:n_trials
        
        % PRIOR
        % inputs(i,1).prior_idx(j) = designMatrix.prior(j); % which prior
        inputs(i,1).prior_mu(j,1) = designMatrix.prior_mu(j); % prior mu
        inputs(i,1).prior_var(j,1) = designMatrix.prior_var(j); % prior var
        inputs(i,1).beta_params(j,:)=beta_params{inputs(i,1).prior_var(j), inputs(i,1).prior_mu(j)}; % parameters of beta distribution for prior
        inputs(i,1).pRew(j,1)=round(98*betarnd(inputs(i).beta_params(j, 1),inputs(i).beta_params(j, 2))+0.5)/100; % probability of reward (sample from prior)
        
        % LIKELIHOOD
        inputs(i,1).n_dots(j,1) = n_dots(designMatrix.evidence(j)); % numbers of dots
        inputs(i,1).n_red(j,1) = sum(rand(inputs(i).n_dots(j),1) < inputs(i).pRew(j)); % number of winning lotteries among current dots
        
        % POSTERIOR
        new_param(1)=inputs(i).beta_params(j,1)+inputs(i).n_red(j); % alpha of posterior distribution
        new_param(2)=inputs(i).beta_params(j,2)+inputs(i).n_dots(j)-inputs(i).n_red(j); % beta of posterior distribution
%         inputs(i,1).posterior(j,1) = new_param(1)/(new_param(1)+new_param(2)); % mean of posterior distribution
        inputs(i,1).posterior(j,1) = (new_param(1)-1)/(new_param(1)+new_param(2)-1); % MOD of posterior distribution
        

        % Outcome valence
        %         inputs(i,1).outcome_valence(j,1) = designMatrix.valence(j); % valence of outcome
        
        % Outcome value
        %         if inputs(i,1).outcome_valence(j,1)==1 % gain
        %             inputs(i,1).outcome_value(j,1) = gain(designMatrix.outcome(j));
        %         elseif inputs(i,1).outcome_valence(j,1)==2 % loss
        %             inputs(i,1).outcome_value(j,1) = gain(designMatrix.outcome(j))*-1;
        %         end
        
        
        % Alternative lottery
        % Alternative lottery = symbol lottery (mean of posterior distribution) +/- differnce
        % Make sure alternative lottery larger than 0 and smaller than 1.
        
        bound=0.4;
        range = [inputs(i,1).posterior(j,1)-bound, inputs(i,1).posterior(j,1)+bound];
        range = max(min(range, 0.994), 0.005);
%         if inputs(i,1).posterior(j,1)-bound<=0.005
%             range=[0.01 inputs(i,1).posterior(j,1)+bound];            
%         elseif inputs(i,1).posterior(j,1)+bound>=0.994
%             range=[inputs(i,1).posterior(j,1)-bound 0.99];
%         else
%             range=[inputs(i,1).posterior(j,1)-bound inputs(i,1).posterior(j,1)+bound];
%         end
        inputs(i,1).pRew_alt(j,1)=round((range(1)+(range(2)-range(1)).*rand)*100)/100;
        inputs(i,1).alt_diff(j,1) = inputs(i,1).pRew_alt(j,1)-inputs(i,1).posterior(j,1);
        
        
    end
    
    % Alternative lottery
    % Alternative lottery = symbol lottery (mean of posterior distribution) +/- differnce
    % Make sure alternative lottery larger than 0 and smaller than 1.
    
    
    %         diff = [-40;-20;-10;10;20;40];
    %         n_diff = numel(diff);
    %         rand_diff = mod(randperm(ceil(n_trials/n_diff)*n_diff), n_diff)+1;
    %         Alt_diff = diff(rand_diff(1:n_trials))/100;
    %         inputs(i,1).alt_diff = Alt_diff;
    %         inputs(i,1).pRew_alt = inputs(i).posterior+Alt_diff;
    %         if all((inputs(i).pRew_alt>=0.005)&(inputs(i).pRew_alt<=0.994))
    %             break
    %          end
    
    %      end
    
    % Outcome for choosing Symbol lottery
    randomPosterior = rand(n_trials, 1);
    inputs(i,1).outcome_sym = (inputs(i).posterior>randomPosterior).*outcome;
    % Outcome for choosing alternative lottery
    randomAlt = rand(n_trials, 1);
    inputs(i,1).outcome_alt = (inputs(i).pRew_alt>randomAlt).*outcome;
    
end

% save inputfile
save(inputfile,'inputs');


