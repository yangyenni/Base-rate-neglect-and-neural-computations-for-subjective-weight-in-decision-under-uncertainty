function prior_symNo = determine_priorSymNo(subID,n_params)
%
% determine symbol number for prior.
%

% symbols assigned to 3 different priors
% n_symbols = 10; % we have 10 possible symbols to choose from.
%n_params = 3;   % we have 3 different priors, one for each symbol.

% list of symbols for using
symbol_list = [1,3,4,5,6,8,9,10];
n_symbols = numel(symbol_list);

% randomly choose n symbols
random_order = randperm(n_symbols);
prior_symNo = symbol_list(random_order(1:prod(n_params)));
if numel(n_params)==2
    prior_symNo = reshape(prior_symNo, n_params(1), n_params(2));
end

% save choosing symbols
filename = ['prior_symNo_' subID '.txt'];
fid =fopen(filename,'w');
for i = 1:n_params(1)
    fprintf(fid,'%i\t',prior_symNo(i,:));
    fprintf(fid,'\n');
end
fclose(fid);