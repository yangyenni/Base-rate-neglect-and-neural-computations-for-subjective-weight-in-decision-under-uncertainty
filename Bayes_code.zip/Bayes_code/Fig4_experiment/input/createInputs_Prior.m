function createInputs_Prior(subID)

% 15/5/2014.
% create input file for the bayesian project: prior learning session.
%
%
%
%
% SWW.2011.
% CHK.20141225.

% set random seed depending on current time
rs=sum(100*clock);
rand('state',rs);

% 2 (number of prior distributions) x 3 (likelihood: amount of evidence) design
% In each trial, subjects see a particular combination of prior and
% likelihood. Prior will be represented by a cue. Likelihood will be
% represented by colored dots (yellow and white).  The number of yellow and
% white dots are determined by a probability drawn from the prior distribution.

% name of inputfile
inputfile = sprintf('prior_%s.mat', subID);
if exist(inputfile,'file')
    error('input file with this subject ID already exists')
end

% Parameters of beta distribution for prior distribution

beta_params = {
    [12,12];
    [2,2]
    };

n_mu = size(beta_params,2);
n_variance = size(beta_params, 1);
n_prior = n_variance*n_mu;


idx = 0;
for v = 1:n_variance
    for m = 1:n_mu
        idx = idx + 1;
        Matrix(idx, :) = [v, m];
    end
end


% blocks and trials
n_repeats_prior = 30;
n_repeats_block = 5; % number of repeats for each prior condition.
nTrialsPB = n_repeats_prior;
nBlocks = n_repeats_block*n_prior; %total number of blocks

% randomly assign prior distribution for each block
prior_set=[];
for n= 1:n_repeats_block
    prior_set=[prior_set;randperm(n_prior)'];
end
% prior_set = mod(randperm(nBlocks)', n_prior)+1;

% randomly assign symbols to represent prior distribution
prior_symNo = determine_priorSymNo(subID,[n_variance,n_mu]);

% assign design for each block
for i=1:nBlocks
    
    idx_prior = prior_set(i); % which prior
    
    inputs(i,1).nTrialsPB = nTrialsPB; % trials per block
    inputs(i,1).prior_symNo = prior_symNo; % which symbols for prior
    inputs(i,1).prior_var = Matrix(idx_prior,1);% 1 represent the small variance;2 represent the large variance
    inputs(i,1).prior_mu = Matrix(idx_prior,2);
    inputs(i,1).prior_current = idx_prior; % current prior
    inputs(i,1).beta_params = repmat(beta_params{inputs(i,1).prior_var, inputs(i,1).prior_mu}, nTrialsPB, 1); % parameters of beta distribution for prior
    
    inputs(i,1).pRew = zeros(nTrialsPB, 1);
    inputs(i,1).outcome = zeros(nTrialsPB, 1);
    for j=1:nTrialsPB
        inputs(i,1).pRew(j, 1) = round(98*betarnd(inputs(i).beta_params(j, 1),inputs(i).beta_params(j, 2))+0.5); % probability of reward (sample from current prior distribution)
        inputs(i,1).outcome(j, 1) = (rand<=(inputs(i).pRew(j, 1)/100)); % whether win the lottery
    end
end

% save inputfile
save(inputfile,'inputs');


