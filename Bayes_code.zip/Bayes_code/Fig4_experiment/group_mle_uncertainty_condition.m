function [allData, stats] = group_mle_uncertainty_condition(sublist, fig_on)

%The function is used to group result of B(Slope) ,C(constant), and r(WL)
%fitted from posterior model


% group results from multiple subjects
% subject list
if nargin<1 | isempty(sublist)
    sublist = textread('sublist','%s','delimiter','\n');
    
else
    if ~iscell(sublist)
        sublist = {sublist};
    end
end
nSubj = numel(sublist);
% whether to draw figures
if nargin<2
    fig_on = 1;
end

% which mle model
logitModel = 'posterior';


% directory
dir_reg = 'mle';
dir_fig = 'figures';

% condition
nameDots = {'3dots', '15dots'};
namePriorVar = {'prior_low_var', 'prior_high_var'};
nDots = numel(nameDots);
nPriorVar = numel(namePriorVar);
subID = sublist{1};%read one of the file to extract parameters
regFile = fullfile(dir_reg, sprintf('mle_prior_uncertainty_%s_%s_%s_%s.mat', logitModel, nameDots{1}, namePriorVar{1}, subID));
load(regFile);
nParameter = numel(nameParameter);
title_parameter = {'b', 'c', 'w_L'};

%the value of idea r stimulated from computer
ideal_r=[0.1107,0.4400;
    0.3781,0.7757];
ideal_rw=(1-ideal_r)./ideal_r;
ideal_log_rw = log(ideal_rw);




% initialize variables
allData = cell(1, nParameter);
for i = 1:nParameter
    allData{i} = zeros( nDots, nPriorVar, nSubj);
end
% start to group data
for s = 1:nSubj
    for d  = 1:nDots
        for v = 1:nPriorVar
            subID = sublist{s};
            regFile = fullfile(dir_reg, sprintf('mle_prior_uncertainty_%s_%s_%s_%s.mat', logitModel, nameDots{d}, namePriorVar{v}, subID));
            load(regFile);
            for i = 1:nParameter
                allData{i}(d, v, s) = x_bestfit(i);
            end
        end
    end
end


%%%%%%%%%%%%%%%%%%%%%%
%%%%% statistics %%%%%
%%%%%%%%%%%%%%%%%%%%%%

idx_parameter = 3; %1=slope; 2=constant; 3=r(wl)

switch idx_parameter
    case {1,2}
        x = reshape(allData{idx_parameter}(1, 1, :), nSubj, 1);
        [H,P,CI] = ttest(x)
        x = reshape(allData{idx_parameter}(1, 2, :), nSubj, 1);
        [H,P,CI] = ttest(x)
        x = reshape(allData{idx_parameter}(2, 1, :), nSubj, 1);
        [H,P,CI] = ttest(x)
        x = reshape(allData{idx_parameter}(2, 2, :), nSubj, 1);
        [H,P,CI] = ttest(x)
    case 3
        x = reshape(allData{idx_parameter}(1, 1, :), nSubj, 1);
        r = ideal_r(1,1);
        [H,P,CI] = ttest(x-r)
        x = reshape(allData{idx_parameter}(1, 2, :), nSubj, 1);
        r = ideal_r(1,2);
        [H,P,CI] = ttest(x-r)
        x = reshape(allData{idx_parameter}(2, 1, :), nSubj, 1);
        r = ideal_r(2,1);
        [H,P,CI] = ttest(x-r)
        x = reshape(allData{idx_parameter}(2, 2, :), nSubj, 1);
        r = ideal_r(2,2);
        [H,P,CI] = ttest(x-r)
end


%%%%%%%%%%%%%%%%%%%%%%
%%%%% statistics %%%%%
%%%%%%%%%%%%%%%%%%%%%%
% ANOVA
d_f1 = 1;
d_f2 = 2;
d_subj = 3;

data = allData{idx_parameter};
n_level = size(data);
all_level = prod(n_level);

level_s = n_level(d_subj);
level_f1 = n_level(d_f1);
level_f2 = n_level(d_f2);

y = zeros(all_level,1);
s = zeros(all_level,1);
f1 = zeros(all_level,1);
f2 = zeros(all_level,1);

idx = 0;
for idx_s = 1:level_s
    for idx_f1 = 1:level_f1
        for idx_f2 = 1:level_f2
            
            idx = idx + 1;
            y(idx) = data(idx_f1,idx_f2,idx_s);
            s(idx) = idx_s;
            f1(idx) = idx_f1;
            f2(idx) = idx_f2;
            
        end
    end
end

stats.wl_anova = rm_anova2(y,s,f1,f2,{'likelihood_variance', 'prior_variance'})


% paired t-test between low and high prior var under 3 dots
x = reshape(allData{idx_parameter}(1, 1, :), nSubj, 1);
y = reshape(allData{idx_parameter}(1, 2, :), nSubj, 1);
[H1,P1,CI1] = ttest(x,y)

% paired t-test between low and high prior var under 15 dots
x = reshape(allData{idx_parameter}(2, 1, :), nSubj, 1);
y = reshape(allData{idx_parameter}(2, 2, :), nSubj, 1);
[H2,P2,CI2] = ttest(x,y)

% paired t-test between 3 dots and 15 dots under low prior var
x = reshape(allData{idx_parameter}(1, 1, :), nSubj, 1);
y = reshape(allData{idx_parameter}(2, 1, :), nSubj, 1);
[H3,P3,CI3] = ttest(x,y)

% paired t-test between 3 dots and 15 dots under high prior var
x = reshape(allData{idx_parameter}(1, 2, :), nSubj, 1);
y = reshape(allData{idx_parameter}(2, 2, :), nSubj, 1);
[H4,P4,CI4] = ttest(x,y)



% difference between "difference of weighting between prior variability "
% and "difference of weighting between likelihood variability"
w_prior = mean(allData{idx_parameter},1);
diff_prior = w_prior(1,2,:) - w_prior(1,1,:); % high_var - low_var
diff_prior = diff_prior(:);

w_likelihood = mean(allData{idx_parameter},2);
diff_likelihood = w_likelihood(2,1,:) - w_prior(1,1,:); % 15dots - 3dots
diff_likelihood = diff_likelihood(:);

[h_new,p_new,ci_new,stat_new] = ttest(diff_prior, diff_likelihood);



%%%%%%%%%%%%%%%%%%%%%%
%%%%% figures %%%%%
%%%%%%%%%%%%%%%%%%%%%%


% bar graph
color = {...
    [0.2,0.4,1];
    [1,0.2,0.2]
    };
if fig_on
    
    pBound = {[0, 65], [-5, 5], [0, 1.4]};
    
    for i = 1:nParameter
        subData = allData{i};
        barData = mean(subData,3);
        stdData = std(subData,0,3);
        seData = stdData./sqrt(nSubj);
        figure;
        fg = fig_setting_default();
        fg.pp = get(gcf,'PaperPosition');
        fg.pp(3) = fg.pp(4);
        set(gcf,...
            'Position',fg.pp,...
            'PaperPosition', fg.pp...
            );
        hold on
        nrow = size(barData,1);
        ncol = size(barData,2);
        h = bar([barData(1,1),barData(2,1);barData(1,2),barData(2,2)],'BarWidth',1);
        drawnow;
        
        for i_h = 1:numel(h)
            set(h(i_h),...
                'EdgeColor', color{i_h},...
                'FaceColor', color{i_h}...
                );
        end
        for j = 1:ncol
%             xposition = get(get(h(j),'children'),'xdata');
%             barsx(j,1:nrow)=mean(xposition,1);
            barsx(j,:) = h(j).XData + h(j).XOffset;
            
        end
        for d = 1:nDots
            for v = 1:nPriorVar
                
                x = barsx(d,v);
                y = allData{i}(d,v,:);
                x = x(:);
                y = y(:);
                plot(x,y,...
                    'Marker', 'o',...
                    'MarkerFaceColor', [0.4, 0.4, 0.4],...
                    'MarkerEdgeColor', [0.4, 0.4, 0.4],...
                    'MarkerSize', 12,...
                    'LineWidth', 3,...
                    'LineStyle', 'none'...
                    );
                
            end
        end
        switch i
            case 3 %wl
                
                y=[ideal_r(1,1),ideal_r(2,1),ideal_r(1,2),ideal_r(2,2)];
                x=[barsx(1,1),barsx(2,1),barsx(1,2),barsx(2,2)];
                plot(x, y,...
                    'Marker', 'd',...
                    'MarkerFaceColor', 'none',...
                    'MarkerEdgeColor', 'k',...
                    'MarkerSize', 18,...
                    'LineWidth', 3,...
                    'LineStyle', 'none'...
                    );
        end
        e = errorbar(barsx, barData,seData);
        for i_e = 1:numel(e)
            set(e(i_e),...
                'Marker','none',...
                'LineStyle','none',...
                'linewidth', 3,...
                'Color', 'k'...
                );
        end
        
        set(gca, 'XTick', mean(barsx,1), 'XTickLabel', namePriorVar);
        if i==3
            set(gca, 'YTick', [0:0.2:1]);
        end
        legend(nameDots, 'Location', 'NorthWest');
        ylim([pBound{i}]);
        title(title_parameter{i});
        
        hold off
        
        % output figure
        print(fullfile(dir_fig,sprintf('parameter_%s_ndotsXPriorVar_%s', title_parameter{i}, logitModel)), '-depsc');
        
    end
    
end







% paired between low and high prior var under 3 dots
high_div_low_in_3dots = mean(reshape(allData{3}(1, 2, :), nSubj, 1))./mean(reshape(allData{3}(1, 1, :), nSubj, 1))
ideal_high_div_low_in_3dots =ideal_r(1,2)/ideal_r(1,1);
% paired between low and high prior var under 15 dots
high_div_low_in_15dots = mean(reshape(allData{3}(2, 2, :), nSubj, 1))./mean(reshape(allData{3}(2, 1, :), nSubj, 1))
ideal_high_div_low_in_15dots=ideal_r(2,2)/ideal_r(2,1);
% paired between 3 dots and 15 dots under low prior var
high_div_low_in_low_prior =  mean(reshape(allData{3}(2, 1, :), nSubj, 1))./mean(reshape(allData{3}(1, 1, :), nSubj, 1))
ideal_high_div_low_in_low_prior=ideal_r(2,1)/ideal_r(1,1);
% paired between 3 dots and 15 dots under high prior var
high_div_low_in_high_prior = mean(reshape(allData{3}(2, 2, :), nSubj, 1))./mean(reshape(allData{3}(1, 2, :), nSubj, 1))
ideal_high_div_low_in_high_prior=ideal_r(2,2)/ideal_r(1,2);





