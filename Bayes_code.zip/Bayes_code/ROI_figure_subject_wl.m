function ROI_figure_subject_wl()

nSubj = 28;


% list_ROI
list_ROI = {
    'OFC_ROI_peak_mask25';
    };
nROI = numel(list_ROI);

% list_cope
list_cope = [1,3,5,7];
nCope = numel(list_cope);
% copo1: small prior variance, large likelihood variance
% cope3: small prior variance, small likelihood variance
% cope5: large prior variance, large likelihood variance
% cope7: large prior variance, small likelihood variance

allData = group_mle_uncertainty_condition([],0);
behavior_data = allData{3};
mean_subject_wl = mean(behavior_data,3);
mean_subject_wl = reshape(mean_subject_wl,1,4);


% directory

dirCope = 'fMRI_GLM/GLM_2/Leave_one_out_beta';
dir_fig = 'figures';
mkdir(dir_fig);

%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% organize data %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%
clear allData
for r = 1:nROI
    
    % roi_name
    roi_name = list_ROI{r};
    
    allData.(roi_name) = NaN(nSubj,nCope);
    for c = 1:nCope
        
        idx_cope = list_cope(c);
        
        filename = fullfile(dirCope,roi_name, sprintf('%s_cope%d.txt', roi_name,  idx_cope));       
        data = load(filename);
        
        allData.(roi_name)(:, c) = data(1:nSubj);
        
        
    end
    
end

%%%%%%%%%%%%%%%%%%%
%%%%% figures %%%%%
%%%%%%%%%%%%%%%%%%%
color_roi = {
    'r';
    };

%%%%% group fitting %%%%%
figure;
fg = fig_setting_default;

hold on

h = NaN(1,nROI);
for r = 1:nROI
    
    % roi_name
    roi_name = list_ROI{r};
    
    current_data = allData.(roi_name);
    meanData = mean(current_data,1);
    semData = std(current_data, 0, 1)./sqrt(nSubj);
    
    [beta] = glmfit(mean_subject_wl, meanData);
    xhat = [min(mean_subject_wl), max(mean_subject_wl)]';
    yhat = glmval(beta, xhat, 'identity');
    
    plot(xhat, yhat,...
        'linestyle', '-',...
        'linewidth', 2,...
        'color', color_roi{r});
    
    h_error = errorbar(mean_subject_wl, meanData, semData);
    set(h_error,...
        'color', 'k',...
        'linestyle', 'none',...
        'linewidth', 2);
    
    h(r) = plot(mean_subject_wl, meanData,...
        'linestyle', 'none',...
        'linewidth', 2,...
        'marker', 'o',...
        'markersize', 12,...
        'markeredgecolor', 'k',...
        'markerfacecolor', color_roi{r});
    
end

hold off

legend(h, list_ROI, 'location', 'NorthWest');

xlabel('subject wL');
ylabel('activation');


% output figure
outputfile = fullfile(dir_fig,['neural_w_L_mean_mask25']);
print(outputfile,'-depsc');
savefig([outputfile, '.fig']);





