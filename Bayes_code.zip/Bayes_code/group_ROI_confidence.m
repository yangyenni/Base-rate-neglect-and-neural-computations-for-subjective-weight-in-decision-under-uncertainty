function group_ROI_confidence()


% subject
nSubj = 28;
%nSubj = 39;

% list_ROI
list_ROI = {
    'mPFC', 'mPFC';
    'OFC_ROI_peak_mask25', 'OFC';
    'HarvardOxford_LPutamen','LPutamen';
    'HarvardOxford_RPutamen','RPutamen';
    };
nROI = size(list_ROI,1);



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% subjective_weight&Confidence %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% directory
model_name = 'GLM_1_confidence';
dirModel = fullfile('fMRI_GLM', model_name, 'beta_dir_leave_one_out');
dirModel_HarvardOxford = fullfile('fMRI_GLM', model_name, 'beta_dir');
dir_fig = 'figures';


% list_cope

list_cope = {
    2, 'subjective weight';
    4, 'Confidence';
    };
nCope = size(list_cope,1);


%%%%% organize %%%%%
for r = 1:nROI
    
    % roi_name
    roi_name = list_ROI{r,1};
    
    switch roi_name
        case {'HarvardOxford_LPutamen', 'HarvardOxford_RPutamen'}
            dirData = fullfile(dirModel_HarvardOxford, roi_name);
        otherwise
            dirData = fullfile(dirModel, roi_name);
    end
    
    allData.(roi_name) = NaN(nSubj, nCope);
    for c = 1:nCope
        
        % cope_name
        cope_name = list_cope{c,1};
        
        % load file
        filename = sprintf('%s_cope%d.txt', roi_name, cope_name);
        filename = fullfile(dirData, filename);
        data = load(filename);
        
        allData.(roi_name)(:,c) = data(1:nSubj);
        
    end
end

%%%%% figure %%%%%
color_bar = {
    [0,0,0];
    [1,1,1];
    };
x_adjust = [-0.15,0.15];
yrange = [-100,100];


% organize data
h_bar = NaN(1,nCope);

figure;
fg = fig_setting_default;

hold on
for r = 1:nROI
    
    % roi_name
    roi_name = list_ROI{r,1};
    
    for c = 1:nCope
        
        data = allData.(roi_name)(:,c);
        meanData = mean(data,1);
        semData = std(data,0,1)./sqrt(nSubj);
        
        xpos = r + x_adjust(c);
        
        h = bar(xpos, meanData);
        if r==1
            h_bar(c) = h;
        end
        set(h,...
            'edgecolor', 'k',...
            'facecolor', color_bar{c},...
            'linewidth', 2,...
            'barwidth', 0.3);
        h_error = errorbar(xpos, meanData, semData);
        set(h_error,...
            'linestyle', 'none',...
            'linewidth', 2,...
            'color', 'k');
        
        % pval
        [h, pval] = ttest(data)
        idx_p = 0;
        if pval<0.001
            idx_p = 1;
            text_p = '***';
        elseif pval>=0.001 & pval<0.01
            idx_p = 1;
            text_p = '**';
        elseif pval>=0.01 & pval<0.05
            idx_p = 1;
            text_p = '*';
        end
        
        if idx_p==1
            x = xpos;
            if meanData>=0
                y = meanData + semData + (yrange(2)-yrange(1))*0.06;
            else
                y = meanData - semData - (yrange(2)-yrange(1))*0.06;
            end
            text(x, y, text_p,...
                'HorizontalAlignment', 'center',...
                'fontsize', 30);
        end
        
    end
end
hold off

xticklabel = list_ROI(:, 2);
set(gca, 'XTick', [1:nROI], 'XTicklabel', xticklabel);
set(gca, 'fontsize', 20, 'linewidth', 2);

xlabel('Factor', 'fontsize', 24);
ylabel('COPE', 'fontsize', 24);

xlim([1-0.5, nROI+0.5]);
ylim(yrange);

legend(h_bar, list_cope(:,2),...
    'fontsize', 20,...
    'location', 'NorthEast');

% output figure
outputfile = fullfile(dir_fig, sprintf('cope_roi_%s', model_name));
print(outputfile,'-depsc');
savefig([outputfile, '.fig']);






%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% prior SD & likelihood SD & confidence %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% directory
model_name = 'GLM_3_confidence';
dirModel = fullfile('fMRI_GLM', model_name, 'beta_dir_leave_one_out');
dirModel_HarvardOxford = fullfile('fMRI_GLM', model_name, 'beta_dir');
dir_fig = 'figures';


% list_ROI
list_ROI = {
    'mSFC', 'mSFC';
    };
nROI = size(list_ROI,1);

% list_cope
list_cope = {
    2, 'prior sd';
    3, 'likelihood sd';
    6, 'Confidence';
    };
nCope = size(list_cope,1);


%%%%% organize %%%%%
for r = 1:nROI
    
    % roi_name
    roi_name = list_ROI{r};
    
    %dirData = fullfile(dirModel, roi_name);
    switch roi_name
        case {'HarvardOxford_LPutamen', 'HarvardOxford_RPutamen'}
            dirData = fullfile(dirModel_HarvardOxford, roi_name);
        otherwise
            dirData = fullfile(dirModel, roi_name);
    end
    
    allData.(roi_name) = NaN(nSubj, nCope);
    for c = 1:nCope
        
        % cope_name
        cope_name = list_cope{c,1};
        
        % load file
        filename = sprintf('%s_cope%d.txt', roi_name, cope_name);
        filename = fullfile(dirData, filename);
        data = load(filename);
        
        allData.(roi_name)(:,c) = data(1:nSubj);
        
    end
end

%%%%% figure %%%%%
color_bar = {
    [0,0,0];
    [0.5,0.5,0.5];
    [1,1,1];
    };
x_adjust = [-0.2,0,0.2];
yrange = [-160,160];

% organize data
h_bar = NaN(1,nCope);

figure;
fg = fig_setting_default;

hold on
for r = 1:nROI
    
    % roi_name
    roi_name = list_ROI{r,1};
    
    
    for c = 1:nCope
        
        data = allData.(roi_name)(:,c);
        meanData = mean(data,1);
        semData = std(data,0,1)./sqrt(nSubj);
        
        xpos = r + x_adjust(c);
        
        h = bar(xpos, meanData);
        if r==1
            h_bar(c) = h;
        end
        set(h,...
            'edgecolor', 'k',...
            'facecolor', color_bar{c},...
            'linewidth', 2,...
            'barwidth', 0.2);
        h_error = errorbar(xpos, meanData, semData);
        set(h_error,...
            'linestyle', 'none',...
            'linewidth', 2,...
            'color', 'k');
        
        % pval
        [h, pval] = ttest(data);
        idx_p = 0;
        if pval<0.001
            idx_p = 1;
            text_p = '***';
        elseif pval>=0.001 & pval<0.01
            idx_p = 1;
            text_p = '**';
        elseif pval>=0.01 & pval<0.05
            idx_p = 1;
            text_p = '*';
        end
        
        if idx_p==1
            x = xpos;
            if meanData>=0
                y = meanData + semData + (yrange(2)-yrange(1))*0.06;
            else
                y = meanData - semData - (yrange(2)-yrange(1))*0.06;
            end
            text(x, y, text_p,...
                'HorizontalAlignment', 'center',...
                'fontsize', 30);
        end
        
    end
end
hold off

xticklabel = list_ROI(:, 2);
set(gca, 'XTick', [1:nROI], 'XTicklabel', xticklabel);
set(gca, 'fontsize', 20, 'linewidth', 2);

xlabel('Factor', 'fontsize', 24);
ylabel('COPE', 'fontsize', 24);

xlim([1-0.5, nROI+0.5]);
ylim(yrange);

legend(h_bar, list_cope(:,2),...
    'fontsize', 20,...
    'location', 'NorthEast');

% output figure
outputfile = fullfile(dir_fig, sprintf('cope_roi_%s', model_name));
print(outputfile,'-depsc');
savefig([outputfile, '.fig']);






