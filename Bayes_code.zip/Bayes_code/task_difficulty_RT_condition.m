function task_difficulty_RT_condition

% check the input arguments
% subject list
if nargin<1
    sublist = textread('sublist','%s','delimiter','\n');
else
    if ~iscell(sublist)
        sublist = {sublist};
    end
end
nSubj = numel(sublist);

dir_fig= 'figures';


% set the diff range from [-0.7 to 0.7]
diff_range=[-0.7:0.2:0.7];
nDiff = numel(diff_range);

% four conditions
nameDots = [3,15];
namePriorVar = {'prior_low_var', 'prior_high_var'};
nDots = numel(nameDots);
nPriorVar = numel(namePriorVar);

nCondition=nPriorVar*nDots;

%set up colors
color_idx={
    [1, 0.5, 0.1];
    [1,0,1];
    'c';
    [0.2,0.2,1];
    };

for n = 1:nSubj
    
    %read data from onset files
    onsetFile = fullfile('fMRI_onset', sprintf('sub%.3d_fmri_onset_1120.mat', n));
    load(onsetFile);
    onsetTitle = fmri_onset.onsetTitle;
    data = fmri_onset.allOnset;
    
    idx_prior_variance=find(strcmp(onsetTitle,'prior_var_index'));
    idx_dots = find(strcmp(onsetTitle, 'likelihood_dots'));
    
    idx_choice = find(strcmp(onsetTitle, 'choice'));
    % check choice
    idx = (data(:,idx_choice)~=-1);
    condition=0;
    % separare condition
    list_legend = cell(1, nCondition);
    for v = 1:nPriorVar
        for d = 1:nDots
            condition=condition+1;
            
            idx_cond = (data(:, idx_prior_variance)==v)& (data(:, idx_dots)==nameDots(d));
            idx_included = idx&idx_cond;
            
            RT_idx = find(strcmp(onsetTitle, 'RT'));
            
            RT = data(idx_included, RT_idx);
            
            
            alternative_lottery_idx =find(strcmp(onsetTitle, 'alternative_lottery'));
            alternative_lottery = data(idx_included, alternative_lottery_idx);
            posterior_mean_subjective_idx =find(strcmp(onsetTitle, 'posterior_mean_subjective'));
            posterior_mean_subjective = data(idx_included, posterior_mean_subjective_idx);

            
            diff_subjective=posterior_mean_subjective-alternative_lottery;
            
            
            for i=1:length(diff_range)-1
                idx_range_subjective = (diff_range(i)<=diff_subjective)&(diff_subjective<diff_range(i+1));
                RT_cat_subjective(n,condition,i)=mean(RT(idx_range_subjective));
                RT_std_cat_subjective(n,condition,i)= std(RT(idx_range_subjective));
                
            end
            
            
            list_legend{condition} = sprintf('%s & %d dots', namePriorVar{v}, nameDots(d));
            
        end
    end
end

%%%%%%%%%%%%%%%%%%
%%%%% figure %%%%%
%%%%%%%%%%%%%%%%%%
list_range = NaN(1,nDiff-1);
for i = 1:nDiff-1
    list_range(i) = (diff_range(i)+diff_range(i+1))/2;
end


%%%%% RT_cat_subjective %%%%%
data = RT_cat_subjective;

figure;
fg=fig_setting_default;
hold on

hp = NaN(1,nCondition);
for c = 1:nCondition
    
    data_condition = data(:,c,:);
    
    xData = list_range;
    xData = xData(:);
    
    meanData = nanmean(data_condition,1);
    meanData = meanData(:);
    
    semData = nanstd(data_condition,0,1)./sqrt(nSubj);
    semData = semData(:);
    
    idx_notnan = ~isnan(meanData);
    xData = xData(idx_notnan);
    meanData = meanData(idx_notnan);
    semData = semData(idx_notnan);
    
    xhat = linspace(min(xData), max(xData), 100);
    param = polyfit(xData, meanData, 2);
    yhat = polyval(param, xhat);
    
    
    
    hp(c) = plot(xData, meanData,...
        'linestyle', 'none',...
        'linewidth', 2,...
        'marker', 'o',...
        'markersize', 9,...
        'markeredgecolor', 'k',...
        'markerfacecolor', color_idx{c});
    
    errorbar(xData, meanData, semData,...
        'color', 'k',...
        'linestyle', 'none',...
        'linewidth', 2);
    
end
hold off

xlabel('subjective_diff','interpreter','none');
ylabel('RT');

xlim([-0.8,0.7]);

legend(hp, list_legend,'interpreter', 'none');
legend('boxoff');

outputfile = fullfile(dir_fig,'N28_Task_difficulity_Condition_subjective_diff');
print(outputfile,'-depsc');
savefig([outputfile, '.fig']);








