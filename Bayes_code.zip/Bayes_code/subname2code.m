function code = subname2code(subID)

% transform subjects' name to subjects code number
% e.g., 'ABC' -> 'sub001'
%
% YYY, 20150513

sublist = textread('sublist','%s','delimiter','\n'); % it seperate by "\n"
idx_sub = find(strcmp(sublist,subID));  %Find indices of nonzero elements
code = sprintf('sub%.3d',idx_sub);
