function [fitting_beta]=Normalize_w_l_prior_likelihood_sd

%This function plot the correlation between normalize prior std/ likelihood std with wl


% directory
dirOnset = 'fMRI_onset';
dir_fig = 'figures';
nSubj=28;

%load data from organized files
for s=1:nSubj
    subID=sprintf('sub%.3d',s);
    onsetFile = fullfile(dirOnset, sprintf('%s_fmri_onset_1120.mat', subID));
    load(onsetFile);
    onsetTitle = fmri_onset.onsetTitle;
    data = fmri_onset.allOnset;
    
    
    idx_choice = find(strcmp(onsetTitle, 'choice'));
    idx_include = (data(:,idx_choice)~=-1);%remove the unchosen trials
    
    w_l_idx=find(strcmp(onsetTitle, 'w_L'));
    w_l= data(idx_include,w_l_idx);
    
    prior_var_idx=find(strcmp(onsetTitle, 'prior_var'));
    prior_var = data(idx_include,prior_var_idx);
    prior_sd = sqrt(prior_var);
    
    %normalize=(x - mean of x)/std
%     normalize_prior_sd = (data(idx_include,prior_var_idx)-mean(data(idx_include,prior_var_idx)))./prior_sd;
    normalize_prior_sd = zscore(prior_sd);
    
    likelihood_var_idx=find(strcmp(onsetTitle, 'likelihood_var'));
    likelihood_var = data(idx_include,likelihood_var_idx);
    likelihood_sd = sqrt(likelihood_var);
    
%     normalize_likelihood_sd = (data(idx_include,likelihood_var_idx)-mean(data(idx_include,likelihood_var_idx)))./likelihood_sd;
    normalize_likelihood_sd = zscore(likelihood_sd);
    
    x=[prior_sd,likelihood_sd];
    x_normalize=[normalize_prior_sd,normalize_likelihood_sd];
    idx_include=~isinf(normalize_likelihood_sd);
    [B,DEV]=glmfit(x_normalize(idx_include,:),w_l(idx_include),'normal');
    
    fitting_beta(s,:)=B; %[B0,B_prior,B_likelihood]
end

%%%%%%%%%%%%%%%%%%%%%%
%%%%% figures %%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%

%remove B0 in fitting beta %Leave only [B_prior,B_likelihood]
fitting_beta=fitting_beta(:,2:3);

barData=mean(fitting_beta,1);
stdBeta = std(fitting_beta,1);
seData = stdBeta./sqrt(nSubj);

%t-test
for n_p=1:size(fitting_beta,2)
    [H,P,CI,stats]=ttest(fitting_beta(:,n_p));
    pval(n_p)=P;
end

xData = [0.7,1.3]
figure;
fg=fig_setting_default;
hold on;
h = bar(xData,barData,'barwidth', 0.8);
set(h, 'FaceColor', 'b');

barsx = h.XData;

set(gca, 'xTick', barsx, 'xTickLabel', {'prior_sd','likelihood_sd'}, 'fontsize', 18);


errorbar(barsx, barData,seData,...
    'Marker','none',...
    'LineStyle','none',...
    'Color', 'k');
hold off;
% ylim([-1.5,1.5]);
ylim([-0.1,0.15]);

yrange = ylim;

for i = 1:numel(pval)
    idx_p = 0;
    if pval(i)<.05 & pval(i)>=0.01
        idx_p = 1;
        text_p = '*';
    elseif pval(i)<0.01 & pval(i)>=0.001
        idx_p = 1;
        text_p = '**';
    elseif pval(i)<0.001
        idx_p = 1;
        text_p = '***';
    end
    
    if idx_p==1
        x = xData(i);
        if barData(i)>=0
            y = barData(i)+seData(i) + 0.03*(max(yrange)-min(yrange));
        else
            y = barData(i)-seData(i) - 0.03*(max(yrange)-min(yrange));
        end
        text(x,y,text_p,'HorizontalAlignment','center','fontsize',24);
        
    end
end



print(fullfile(dir_fig,'w_l_prior_lilihood_sd_fitting_normalize'), '-depsc');

